# mysql-replay
Read the MySQL protocol package file pCAP in tcpdump, parse it into SQL and result sets, and compare the results in other environments
